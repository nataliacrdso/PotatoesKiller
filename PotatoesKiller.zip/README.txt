Olá, você está jogando Potatoes Killer, um jogo 2D em que você é um gatinho bruxo enfrentando batatas malignas e ao atingir 5000 pontos você enfrentará o rei das batatas!

Controles:
Setas para movimentar o personagem
X - atirar bolas de fogo


Desenvolvido por:
Natalia Cardoso 
Disciplina de Linguagem de Programação Aplicada - Uninter

Obrigada por jogar!